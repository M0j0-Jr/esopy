#!/usr/bin/python

print("Hi! 123")