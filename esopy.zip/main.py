#!/usr/bin/python
import decoder
import dontEdit

# isopy consisted of 4 character strings with 4 possible letters (a, b, c, and d) with 
# different ascii characters assigned unique 4 letter character strings.

# run main.py to test your isopy script.
# it will automatically decode the isopy script written in codeHere.py using decoder.py,
# and then main.py will run the decoded isopy script in dontEdit.py. 

# if you want to find a character string for a specific letter, refer to glossary.txt.